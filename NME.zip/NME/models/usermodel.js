var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var newSchema = new Schema({
    code:String,
    name:String,
    batch:Number,
    stock:Number,
    deal:Number,
    free:Number,
    mrp:Number,
    company:String
});
var newModel = mongoose.model('Collection', newSchema);
const data = new newModel({code:'PACKTAG',name:'TAG ROLL',batch:'30523',stock:'15',deal:'0',free:'0',mrp:'0',comapny:'General Comapany'})
data.save();
module.exports = newModel;