const express = require('express')
const mongoose = require('mongoose')
const app = express()
const csvModel = require('./models/usermodel')
app.use(express.json())
var XLSX = require("xlsx")
var workbook = XLSX.readFile("Data.xlsx")
let worksheet = workbook.Sheets[workbook.SheetNames[0]];
for ( let index = 1; index<20; index++) {
  const product={
  "code": worksheet[`A${index}`].v,
   "name" : worksheet[`B${index}`].v,
   "batch" : worksheet[`C${index}`],
   "stock" : worksheet[`D${index}`].v,
   "deal" : worksheet[`E${index}`],
   "free" : worksheet[`F${index}`].v,
   "mrp" : worksheet[`G${index}`].v,
   "rate": worksheet[`H${index}`].v,
   "exp" : worksheet[`I${index}`].v,
   "company" : worksheet[`J${index}`],
  "supplier": worksheet[`K${index}`]
};
console.log(product);
}
mongoose.connect("mongodb://localhost:27017/Mynewdb",{
    useNewUrlParser:true,
    useUnifiedTopology:true
},(err)=>{
    if(!err){
        console.log("Connected")
    }else{
        console.log("error")
    }
})

app.get('/',(req,res)=>{
    csvModel.find ((err,data)=>{
        if(err){
            console.log(err)
        }else{
            if(data!=''){
                res.render('demo',{data:data})
            }else{
                res.render('demo',{data:''})
            }
        }
    });
})

app.listen(3000,()=>{
    console.log("listening on port 3000")
})